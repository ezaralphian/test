import { Music } from './music.interface';

export interface MusicResults {
    resultCount: number;
    results: Music[];
}
