export interface Music {
    wrapperType?: string;
    kind?: string;
    artistId?: number;
    collectionId?: number;
    trackId?: number;
    artistName?: string;
    collectionName?: string;
    trackName?: string;
    collectionCensoredName?: string;
    trackCensoredName?: string;
    artistViewUrl?: string;
    collectionViewUrl?: string;
    feedUrl?: string;
    trackViewUrl?: string;
    artworkUrl30?: string;
    artworkUrl60?: string;
    artworkUrl100?: string;
    artworkUrl600?: string;
    collectionPrice?: number;
    trackPrice?: number;
    trackRentalPrice?: number;
    collectionHdPrice?: number;
    trackHdPrice?: number;
    trackHdRentalPrice?: number;
    releaseDate?: string; // Date
    collectionExplicitness?: string;
    trackExplicitness?: string;
    trackCount?: number;
    country?: string;
    currency?: string;
    primaryGenreName?: string;
    contentAdvisoryRating?: string;
    genreIds?: string[];
    genres?: string[];
}
